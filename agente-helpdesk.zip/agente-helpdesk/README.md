# 🤖 Agente de Helpdesk — TechStore
### Evaluación Parcial N°2 — ISY0101 Ingeniería de Soluciones con IA

Agente inteligente de soporte al cliente construido con **LangChain** y **GitHub Models API**, capaz de integrar herramientas de consulta, escritura y razonamiento en un flujo de trabajo organizacional automatizado.

---

## 📐 Arquitectura del Sistema

```
┌─────────────────────────────────────────────────────────┐
│                    USUARIO / CLIENTE                     │
└────────────────────────┬────────────────────────────────┘
                         │ mensaje
                         ▼
┌─────────────────────────────────────────────────────────┐
│                  AgenteHelpdesk                          │
│                                                          │
│   ┌─────────────┐    ┌──────────────────────────────┐   │
│   │  MEMORIA    │    │     PLANIFICADOR (LLM)        │   │
│   │             │    │   Ciclo ReAct:                │   │
│   │ • Buffer    │◄──►│   1. Razona la consulta       │   │
│   │ • Ventana   │    │   2. Selecciona herramienta   │   │
│   │ • Resumen   │    │   3. Ejecuta                  │   │
│   └─────────────┘    │   4. Observa resultado        │   │
│                      │   5. Genera respuesta final   │   │
│                      └──────────────┬───────────────┘   │
│                                     │                    │
│              ┌──────────────────────┼──────────────┐    │
│              ▼              ▼       ▼       ▼       │    │
│         buscar_faq  consultar  calcular  crear      │    │
│                     _pedido   _reembolso _ticket    │    │
│              │              │       │       │       │    │
│              └──────────────┴───────┴───────┘       │    │
│                         data/faq.json               │    │
└─────────────────────────────────────────────────────┘
```

---

## 🗂️ Estructura del Proyecto

```
agente-helpdesk/
├── agent/
│   ├── __init__.py
│   ├── agent.py        # Agente principal (LangChain + planificación)
│   ├── tools.py        # 4 herramientas personalizadas
│   └── memory.py       # 3 estrategias de memoria
├── data/
│   └── faq.json        # Base de conocimiento + datos de pedidos
├── tests/
│   └── test_agent.py   # Pruebas de herramientas
├── docs/
│   └── architecture.md # Documentación técnica
├── main.py             # Punto de entrada (demo + chat interactivo)
├── requirements.txt
├── .env.example
└── .gitignore
```

---

## ⚙️ Instalación y Configuración

### 1. Clonar el repositorio
```bash
git clone https://github.com/tu-usuario/agente-helpdesk.git
cd agente-helpdesk
```

### 2. Crear entorno virtual
```bash
python -m venv venv
source venv/bin/activate.fish   # Fish shell (CachyOS/Arch)
source venv/bin/activate        # Bash/Zsh
```

### 3. Instalar dependencias
```bash
pip install -r requirements.txt
```

### 4. Configurar credenciales
```bash
cp .env.example .env
```
Edita `.env` y agrega tu GitHub Token:
```
OPENAI_BASE_URL=https://models.inference.ai.azure.com
OPENAI_API_KEY=tu_github_token_aqui
```

> Obtén tu token en: https://github.com/settings/tokens

---

## 🚀 Ejecución

### Demo automático (6 escenarios de prueba)
```bash
python main.py
```

### Chat interactivo
```bash
python main.py --chat
```

### Pruebas de herramientas
```bash
python tests/test_agent.py
```

---

## 🛠️ Herramientas del Agente

| Herramienta | Tipo | Descripción |
|---|---|---|
| `buscar_faq` | Consulta | Busca en la base de preguntas frecuentes |
| `consultar_estado_pedido` | Consulta API | Retorna el estado de un pedido por número |
| `calcular_reembolso` | Razonamiento | Calcula el monto de devolución según política |
| `crear_ticket_soporte` | Escritura | Genera un ticket cuando no hay solución directa |

---

## 🧠 Estrategias de Memoria

| Tipo | Clase | Comportamiento |
|---|---|---|
| Buffer | `MemoriaBuffer` | Guarda todo el historial completo |
| Ventana | `MemoriaVentana` | Solo conserva las últimas k interacciones |
| Resumen | `MemoriaResumen` | Comprime el historial con el LLM |

---

## 📋 Flujo de Planificación

El agente sigue este esquema de prioridades (IE5):

```
Consulta recibida
      │
      ├─ ¿Contiene número ORD-XXX? ──► consultar_estado_pedido
      │
      ├─ ¿Menciona devolución + monto? ──► calcular_reembolso
      │
      ├─ ¿Es pregunta sobre política? ──► buscar_faq
      │
      └─ ¿Problema complejo/sin solución? ──► crear_ticket_soporte
```

---

## 🔧 Stack Tecnológico

- **LangChain 1.x** — Framework de agentes
- **langchain-openai** — Integración con API compatible OpenAI
- **GitHub Models API** — Backend LLM (gpt-4.1)
- **Python 3.14** — Lenguaje base

---

## 📚 Referencias

- Chase, H. (2024). *LangChain Documentation*. https://python.langchain.com/
- GitHub. (2024). *GitHub Models*. https://github.com/marketplace/models
- Yao, S. et al. (2022). *ReAct: Synergizing Reasoning and Acting in Language Models*. https://arxiv.org/abs/2210.03629
- LangChain AI. (2024). *create_agent API Reference*. https://python.langchain.com/api_reference/langchain/agents/langchain.agents.agent.create_agent.html
